#pragma once
string NOM_1 = "Leonardo DiCaprio";
int ANNEE_NAISSANCE_1 = 1974;
string BIO_1 = "Leonardo DiCaprio is an American actor and producer. His Name was Inspired by a DaVinci Painting.";

string NOM_2 = "Brad Pitt";
int ANNEE_NAISSANCE_2 = 1963;
string BIO_2 = "William Bradley Pitt is an American actor and film producer. He won his first acting Oscar for his role in 'Once Upon a Time in Hollywood' in 2020.";

string NOM_3 = "Margot Robbie";
int ANNEE_NAISSANCE_3 = 1990;
string BIO_3 = "Margot Elise Robbie is an Australian actress and film producer. She gained international recognition for her role as Barbie in Barbie.";

string TITRE_1 = "Once Upon a Time in Hollywood";
int ANNEE_SORTIE_1 = 2019;
string REALISATEUR_1 = "Quentin Tarantino";
Categorie CATEGORIE_1 = Categorie::DRAME;
int DUREE_1 = 161;

string TITRE_2 = "The Wolf of Wall Street";
int ANNEE_SORTIE_2 = 2013;
string REALISATEUR_2 = "Martin Scorsese";
Categorie CATEGORIE_2 = Categorie::COMEDIE;
int DUREE_2 = 180;

string TITRE_3 = "Inception";
int ANNEE_SORTIE_3 = 2010;
string REALISATEUR_3 = "Christopher Nolan";
Categorie CATEGORIE_3 = Categorie::ACTION;
int DUREE_3 = 148;

string TITRE_4 = "Fight Club";
int ANNEE_SORTIE_4 = 1999;
string REALISATEUR_4 = "David Fincher";
Categorie CATEGORIE_4 = Categorie::COMEDIE;
int DUREE_4 = 139;

string AUTEUR_1 = "Kevin";
string COMMENTAIRE_1 = "Super film!";
int NOTE_1 = 5;

string AUTEUR_2 = "Ryan";
string COMMENTAIRE_2 = "Je n'ai pas compris la fin...";
int NOTE_2 = 2;

string AUTEUR_3 = "Alex";
string COMMENTAIRE_3 = "Ce film est terrible :(";
int NOTE_3 = 1;

string SEPARATEUR_1 = "\033[35m--------------------------------------------------------------------------------------\033[0m\n";
string SEPARATEUR_2 = "\033[35m======================================================================================\033[0m\n";

string ASCII_ART = R"(
 /$$$$$$$   /$$$$$$  /$$   /$$     /$$ /$$$$$$$$ /$$       /$$$$$$ /$$   /$$       /$$$$$$$$ /$$$$$$$    /$$  
| $$__  $$ /$$__  $$| $$  |  $$   /$$/| $$_____/| $$      |_  $$_/| $$  / $$      |__  $$__/| $$__  $$ /$$$$  
| $$  \ $$| $$  \ $$| $$   \  $$ /$$/ | $$      | $$        | $$  |  $$/ $$/         | $$   | $$  \ $$|_  $$  
| $$$$$$$/| $$  | $$| $$    \  $$$$/  | $$$$$   | $$        | $$   \  $$$$/          | $$   | $$$$$$$/  | $$  
| $$____/ | $$  | $$| $$     \  $$/   | $$__/   | $$        | $$    >$$  $$          | $$   | $$____/   | $$  
| $$      | $$  | $$| $$      | $$    | $$      | $$        | $$   /$$/\  $$         | $$   | $$        | $$  
| $$      |  $$$$$$/| $$$$$$$$| $$    | $$      | $$$$$$$$ /$$$$$$| $$  \ $$         | $$   | $$       /$$$$$$
|__/       \______/ |________/|__/    |__/      |________/|______/|__/  |__/         |__/   |__/      |______/
    )";