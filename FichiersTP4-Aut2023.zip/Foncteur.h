#pragma once
#include "Media.h"

// TODO: comparer les medias par note d'evaluation croissante
class FoncteurComparerMedia {
};

// TODO: rechercher un media par son nom
class FoncteurRechercheNomMedia {
};

// TODO: rechercher un utilisateur par son nom
class FoncteurRechercheNomUtilisateur {

};
