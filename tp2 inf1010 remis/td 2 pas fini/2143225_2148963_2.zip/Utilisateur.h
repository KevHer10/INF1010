/**
 * Declaration de la classe Utilisateur
 * \author Remi Marche et Rebay Mohamed
 * \date 22 septembre 2023
 * Cree le 22 septembre 2023
 */

#pragma once
#include <memory>
#include <string>
#include <vector>
#include "Film.h"

using namespace std;

class Utilisateur {
 public:
  // Constructeur
  Utilisateur(const string& nom, const string& mdp);

  // Getters
  string getNomUtilisateur() const;
  vector<shared_ptr<Film>> getFilmsVus() const;

  // Setters
  void setNomUtilisateur(const string& nom);
  void setMotDePasse(const string& mdp);

  // Méthodes fonctionnelles
  void ajouterFilm(shared_ptr<Film> film);
  bool verifierConnexion(const string& mdp) const;

 private:
  string nomUtilisateur_;
  string motDePasse_;
  vector<shared_ptr<Film>> filmsVus_;
};
