/**
 * Programme principal de Polyflix. Permet de gerer des films et des
 * utilisateurs. On peut creer un compte, se connecter, afficher la liste des
 * films, visionner un film, afficher les films visionnes, modifier le mot de
 * passe et se deconnecter.
 * \author Remi Marche et Rebay Mohamed
 * \date 22 septembre 2023
 * Cree le 22 septembre 2023
 */

#include <fstream>
#include <functional>
#include <iostream>
#include <sstream>

#include "Film.h"

#include "Acteur.h"
#include "Constants.h"
#include "Critique.h"
#include "Polyflix.h"
#include "test.h"

void afficherMenu() {
  cout << "\033[33mEntrez un chiffre pour : \033[0m" << endl;
  cout << "\033[32m1. Rouler les tests\033[0m" << endl;
  cout << "\033[32m2. Creer un compte\033[0m" << endl;
  cout << "\033[32m3. Se connecter\033[0m" << endl;
  cout << "\033[32m4. Afficher la liste des films\033[0m" << endl;
  cout << "\033[32m5. Visionner un film\033[0m" << endl;
  cout << "\033[32m6. Afficher les films que j'ai visionnes\033[0m" << endl;
  cout << "\033[32m7. Modifier mot de passe\033[0m" << endl;
  cout << "\033[32m8. Se deconnecter\033[0m" << endl;
  cout << "\033[31m0. Quitter\033[0m" << endl;

  cout << "\033[33mEntrez votre choix : \033[0m";
}

int main() {
  cout << ASCII_ART << "\n\n";

  cout << "\033[33m================================ \033[0m" << endl;
  cout << "\033[33m     Bienvenue sur Polyflix      \033[0m" << endl;
  cout << "\033[33m================================ \033[0m" << endl;

  Polyflix polyflix;

  Film* film1 =
      new Film(TITRE_1, ANNEE_SORTIE_1, REALISATEUR_1, CATEGORIE_1, DUREE_1);
  vector<shared_ptr<Acteur>> acteursOnceUponATimeInHollywood = {
      make_shared<Acteur>(NOM_1, ANNEE_NAISSANCE_1, BIO_1),
      make_shared<Acteur>(NOM_2, ANNEE_NAISSANCE_2, BIO_2),
      make_shared<Acteur>(NOM_3, ANNEE_NAISSANCE_3, BIO_3)};

  vector<Critique*> critiquesOnceUponATimeInHollywood = {
      new Critique(AUTEUR_1, COMMENTAIRE_1, NOTE_1),
      new Critique(AUTEUR_2, COMMENTAIRE_2, NOTE_2)};

  film1->setActeurs(acteursOnceUponATimeInHollywood);
  film1->setCritiques(critiquesOnceUponATimeInHollywood);

  Film* film2 =
      new Film(TITRE_2, ANNEE_SORTIE_2, REALISATEUR_2, CATEGORIE_2, DUREE_2);
  vector<shared_ptr<Acteur>> acteursWolfOfWallStreet = {
      make_shared<Acteur>(NOM_1, ANNEE_NAISSANCE_1, BIO_1),
      make_shared<Acteur>(NOM_2, ANNEE_NAISSANCE_2, BIO_2)};

  vector<Critique*> critiquesWolfOfWallStreet = {
      new Critique(AUTEUR_1, COMMENTAIRE_1, NOTE_1)};

  film2->setActeurs(acteursWolfOfWallStreet);
  film2->setCritiques(critiquesWolfOfWallStreet);

  Film* film3 =
      new Film(TITRE_3, ANNEE_SORTIE_3, REALISATEUR_3, CATEGORIE_3, DUREE_3);
  vector<shared_ptr<Acteur>> acteursInception = {
      make_shared<Acteur>(NOM_1, ANNEE_NAISSANCE_1, BIO_1)};

  vector<Critique*> critiquesInception = {
      new Critique(AUTEUR_2, COMMENTAIRE_2, NOTE_2)};

  film3->setActeurs(acteursInception);
  film3->setCritiques(critiquesInception);

  Film* film4 =
      new Film(TITRE_4, ANNEE_SORTIE_4, REALISATEUR_4, CATEGORIE_4, DUREE_4);
  vector<shared_ptr<Acteur>> acteursFightClub = {
      make_shared<Acteur>(NOM_2, ANNEE_NAISSANCE_2, BIO_2)};

  vector<Critique*> critiquesFightClub = {
      new Critique(AUTEUR_3, COMMENTAIRE_3, NOTE_3)};

  film4->setActeurs(acteursFightClub);
  film4->setCritiques(critiquesFightClub);

  Utilisateur user1 = {AUTEUR_1, MOT_DE_PASSE_1};
  Utilisateur user2 = {AUTEUR_2, MOT_DE_PASSE_2};
  Utilisateur user3 = {AUTEUR_3, MOT_DE_PASSE_3};

  polyflix += film1;
  polyflix += film2;
  polyflix += film3;
  polyflix += film4;

  polyflix += user1;
  polyflix += user2;
  polyflix += user3;

  bool connecte = false;
  string nomUtilisateurConnecte;
  int choix;
  string emptyDummyString = "";
  do {
    afficherMenu();
    cin >> choix;
    getline(cin, emptyDummyString);
    cout << SEPARATEUR_2;

    switch (choix) {
      case 1: {
        cout << "Lancement des tests..." << endl;
        lancerTests(polyflix);
        break;
      }
      case 2: {
        while (true) {
          string nomUtilisateur = "";
          while (nomUtilisateur == "") {
            cout << "Entrez votre nom d'utilisateur: ";
            getline(cin, nomUtilisateur);
          }
          string motDePasse = "";
          while (motDePasse == "") {
            cout << "Entrez votre mot de passe: ";
            getline(cin, motDePasse);
          }
          Utilisateur utilisateur(nomUtilisateur, motDePasse);

          if (!(polyflix += utilisateur)) {
            cout << "Ce nom d'utilisateur existe deja. Veuillez reessayer."
                 << endl;
          } else {
            break;
          }
        }

        cout << "Bienvenue! Connectez-vous pour continer." << endl;

        cout << SEPARATEUR_2 << endl;
        break;
      }
      case 3: {
        if (connecte) {
          cout << "Vous etes deja connecte" << endl << SEPARATEUR_2;
          break;
        }
        string utilisateur = "";
        cout << "Connexion" << endl << "Entrez le nom d'utilisateur: ";
        getline(cin, utilisateur);

        string motDePasse = "";
        cout << "Entrez le mot de passe: ";
        getline(cin, motDePasse);

        connecte = polyflix.connecterUtilisateur(utilisateur, motDePasse);
        nomUtilisateurConnecte = utilisateur;

        if (connecte) {
          cout << "Bravo, vous etes maintenant connectes!" << endl;
        } else {
          cout << "Utilisateur ou mot de passe incorrect" << endl;
        }

        cout << SEPARATEUR_2;
        break;
      }
      case 4: {
        cout << polyflix;
        break;
      }
      case 5: {
        if (!connecte) {
          cout << "Vous devez etre connecte pour visionner un film" << endl
               << SEPARATEUR_2;
          break;
        }
        string titreFilm = "";
        cout << "Entrez le titre du film que vous voulez visionner: ";
        getline(cin, titreFilm);

        if (titreFilm == "") {
          cout << "Le titre du film ne peut pas etre vide" << endl;
          cout << SEPARATEUR_2;
          break;
        }

        if (polyflix.visionnerFilm(nomUtilisateurConnecte, titreFilm)) {
          cout << "Vous avez visionne le film " << titreFilm << endl;
        } else {
          cout << "Le film \"" << titreFilm << "\" n'existe pas" << endl;
        }

        cout << SEPARATEUR_2 << endl;
        break;
      }
      case 6: {
        if (!connecte) {
          cout << "Vous devez etre connecte pour voir vos films visionnes"
               << endl
               << SEPARATEUR_2;
          break;
        }

        cout << "Voici la liste des films que vous avez visionnes:" << endl;

        const auto films =
            polyflix.listerFilmsVisionnesParUtilisateur(nomUtilisateurConnecte);

        if (films.size() > 0) {
          for (const auto& film : films) {
            cout << *film << endl;
          }
        } else {
          cout << "Vous n'avez pas encore visionne de films" << endl;
        }
        cout << SEPARATEUR_2;
        break;
      }
      case 7: {
        if (!connecte) {
          cout << "Vous devez etre connecte pour modifier votre mot de passe"
               << endl
               << SEPARATEUR_2;
          break;
        }
        string motDePasse = "";
        cout << "Entrez votre nouveau mot de passe: ";
        getline(cin, motDePasse);

        if (polyflix.modifierMotDePasse(nomUtilisateurConnecte, motDePasse)) {
          cout << "Votre mot de passe a ete modifie avec succes!" << endl;
        } else {
          cout << "Une erreur est survenue. Veuillez reessayer." << endl;
        }

        cout << SEPARATEUR_2;
        break;
      }
      case 8: {
        if (!connecte) {
          cout << "Vous devez etre connecte pour vous deconnecter" << endl
               << SEPARATEUR_2;
          break;
        }
        connecte = false;
        nomUtilisateurConnecte = "";
        cout << "Vous avez ete deconnecte avec succes!" << endl;
        cout << SEPARATEUR_2;
        break;
      }
      case 0:
        cout << "Au revoir!" << endl;
        break;
      default:
        cout << "Choix invalide. Veuillez reessayer." << endl;
        break;
    }
  } while (choix != 0);

  return 0;
}
