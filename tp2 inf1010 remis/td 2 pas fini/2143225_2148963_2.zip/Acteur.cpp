/**
 * Implementation de la classe Acteur
 * \author Remi Marche et Rebay Mohamed
 * \date 22 septembre 2023
 * Cree le 22 septembre 2023
 */

#include "Acteur.h"

// Constructeurs
Acteur::Acteur() : nom_(""), anneeNaissance_(0), biographie_("") {}

Acteur::Acteur(std::string nom, int anneeNaissance, std::string biographie)
    : nom_(nom), anneeNaissance_(anneeNaissance), biographie_(biographie) {}

/// @brief Constructeur par copie d'un acteur
/// @param acteur L'acteur à copier
Acteur::Acteur(const Acteur& acteur)
    : nom_(acteur.nom_),
      anneeNaissance_(acteur.anneeNaissance_),
      biographie_(acteur.biographie_) {}

/// @brief l'opérateur d'affectation d'un acteur
/// @param acteur L'acteur à copier
/// @return L'acteur copié, pour permettre les assignations en cascade
Acteur& Acteur::operator=(const Acteur& acteur) {
  if (this == &acteur) {
    return *this;
  }

  nom_ = acteur.nom_;
  anneeNaissance_ = acteur.anneeNaissance_;
  biographie_ = acteur.biographie_;

  return *this;
}

// Getters
string Acteur::getNom() const {
  return nom_;
}

int Acteur::getAnneeNaissance() const {
  return anneeNaissance_;
}

string Acteur::getBiographie() const {
  return biographie_;
}

// Setters
void Acteur::setNom(const std::string nom) {
  this->nom_ = nom;
}

void Acteur::setAnneeNaissance(int anneeNaissance) {
  this->anneeNaissance_ = anneeNaissance;
}

void Acteur::setBiographie(const std::string bio) {
  this->biographie_ = bio;
}

/// @brief Verify if two actors are the same
/// @param acteur The actor to compare with
/// @return true if the actors are the same, false otherwise
bool Acteur::operator==(const Acteur& acteur) const {
  return nom_ == acteur.nom_ && anneeNaissance_ == acteur.anneeNaissance_ &&
         biographie_ == acteur.biographie_;
}

/// @brief Verify if two actors are different
/// @param acteur The actor to compare with
/// @return true if the actors are different, false otherwise
bool Acteur::operator!=(const Acteur& acteur) const {
  return !this->operator==(acteur);
}

/// @brief Affiche un acteur
/// @param os Output stream ou afficher l'acteur
/// @param acteur L'acteur à afficher
/// @return l'output stream, pour chainer.
ostream& operator<<(ostream& os, const Acteur& acteur) {
  os << acteur.nom_ << endl
     << SEPARATEUR_SIMPLE << endl
     << "\tDate de naissance: " << acteur.anneeNaissance_ << endl
     << "\tBiographie: " << acteur.biographie_ << endl
     << SEPARATEUR_SIMPLE << endl;

  return os;
}
