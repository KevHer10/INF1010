/**
 * Implementation de la classe Utilisateur
 * \author Remi Marche et Rebay Mohamed
 * \date 22 septembre 2023
 * Cree le 22 septembre 2023
 */

#include "Utilisateur.h"

Utilisateur::Utilisateur(const string& nom, const string& mdp)
    : nomUtilisateur_(nom), motDePasse_(mdp) {}

string Utilisateur::getNomUtilisateur() const {
  return nomUtilisateur_;
}

vector<shared_ptr<Film>> Utilisateur::getFilmsVus() const {
  return filmsVus_;
}

void Utilisateur::setNomUtilisateur(const string& nom) {
  nomUtilisateur_ = nom;
}

void Utilisateur::setMotDePasse(const string& mdp) {
  motDePasse_ = mdp;
}

/// @brief Ajoute un film à la liste des films vus par l'utilisateur
/// @param film Le film à ajouter
void Utilisateur::ajouterFilm(shared_ptr<Film> film) {
  filmsVus_.push_back(film);
}

/// @brief Vérifie si le mot de passe entré correspond au mot de passe de
/// l'utilisateur
/// @param mdp Le mot de passe à vérifier
/// @return true si le mot de passe est correct, false sinon
bool Utilisateur::verifierConnexion(const string& mdp) const {
  return mdp == motDePasse_;
}
