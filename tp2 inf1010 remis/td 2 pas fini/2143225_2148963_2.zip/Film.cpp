/**
 * Implementation de la classe Film
 * \author Remi Marche et Rebay Mohamed
 * \date 22 septembre 2023
 * Cree le 22 septembre 2023
 */

#include "Film.h"
#include <iomanip>
#include <iostream>

// Constructeurs
Film::Film()
    : titre_(""),
      anneeDeSortie_(0),
      realisateur_(""),
      categorie_(Categorie::ACTION),
      duree_(0) {}

Film::Film(string titre,
           int anneeDeSortie,
           string realisateur,
           Categorie categorie,
           int duree)
    : titre_(titre),
      anneeDeSortie_(anneeDeSortie),
      realisateur_(realisateur),
      categorie_(categorie),
      duree_(duree) {}

/// @brief Constructeur par copie d'un film
/// @param film Le film à copier
Film::Film(const Film& film)
    : titre_(film.titre_),
      anneeDeSortie_(film.anneeDeSortie_),
      realisateur_(film.realisateur_),
      categorie_(film.categorie_),
      duree_(film.duree_),
      acteurs_(film.acteurs_),
      critiques_() {
  for (const auto& critique : film.critiques_) {
    critiques_.push_back(make_unique<Critique>(*critique));
  }
}

/// @brief l'opérateur d'affectation d'un film
/// @param film Le film à copier
/// @return Le film copié, pour permettre les assignations en cascade
Film& Film::operator=(const Film& film) {
  if (this == &film) {
    return *this;
  }

  titre_ = film.titre_;
  anneeDeSortie_ = film.anneeDeSortie_;
  realisateur_ = film.realisateur_;
  categorie_ = film.categorie_;
  duree_ = film.duree_;

  acteurs_ = film.acteurs_;

  critiques_.clear();
  for (const auto& critique : film.critiques_) {
    critiques_.push_back(make_unique<Critique>(*critique));
  }

  return *this;
}

// Getters
string Film::getTitre() const {
  return titre_;
}

string Film::getRealisateur() const {
  return realisateur_;
}

int Film::getAnneeDeSortie() const {
  return anneeDeSortie_;
}

Categorie Film::getCategorie() const {
  return categorie_;
}

int Film::getDuree() const {
  return duree_;
}

/// @brief Retourne la liste des acteurs du film
/// @return La liste des acteurs du film
vector<shared_ptr<Acteur>> Film::getActeurs() const {
  return acteurs_;
}

/// @brief Retourne la liste des critiques du film
/// @return La liste des critiques du film
vector<unique_ptr<Critique>> Film::getCritiques() const {
  vector<unique_ptr<Critique>> resultat;
  for (const auto& critique : critiques_) {
    resultat.push_back(make_unique<Critique>(*critique));
  }
  return resultat;
}

int Film::getNbActeurs() const {
  return (int)acteurs_.size();
}

int Film::getNbCritiques() const {
  return (int)critiques_.size();
}

// Setters
void Film::setTitre(string titre) {
  this->titre_ = titre;
}

void Film::setRealisateur(string realisateur) {
  this->realisateur_ = realisateur;
}

void Film::setAnneeDeSortie(int anneeDeSortie) {
  this->anneeDeSortie_ = anneeDeSortie;
}

void Film::setCategorie(Categorie categorie) {
  this->categorie_ = categorie;
}

void Film::setDuree(int duree) {
  this->duree_ = duree;
}

/// @brief Remplace la liste des acteurs du film par une nouvelle liste
/// @param acteurs La nouvelle liste d'acteurs
void Film::setActeurs(vector<shared_ptr<Acteur>> acteurs) {
  this->acteurs_ = acteurs;
}

/// @brief Remplace la liste des critiques du film par une nouvelle liste
/// @param critiquesVec La nouvelle liste de critiques
void Film::setCritiques(vector<Critique*> critiquesVec) {
  critiques_.clear();
  for (const auto& critique : critiquesVec) {
    critiques_.push_back(make_unique<Critique>(*critique));
  }
}

// Méthodes fonctionnelles
/// @brief trouve un acteur dans la liste des acteurs du film
/// @param nom Le nom de l'acteur à trouver
/// @return Un pointeur vers l'acteur si trouvé, nullptr sinon
shared_ptr<Acteur> Film::trouverActeur(const string nom) const {
  for (const auto& acteur : acteurs_) {
    if (acteur->getNom() == nom) {
      return acteur;
    }
  }

  return nullptr;
}

/// @brief trouve une critique dans la liste des critiques du film
/// @param nom Le nom de l'auteur de la critique à trouver
/// @return Un pointeur vers la critique si trouvée, nullptr sinon
unique_ptr<Critique> Film::trouverCritique(const string nom) const {
  for (const auto& critique : critiques_) {
    if (critique->getAuteur() == nom) {
      return make_unique<Critique>(*critique);
    }
  }

  return nullptr;
}

/// @brief Verifie si un acteur est présent dans la liste des acteurs du film
/// @param nomActeur Le nom de l'acteur à trouver
/// @return true si l'acteur est présent, false sinon
bool Film::isActeurPresent(string nomActeur) const {
  for (const auto& acteur : acteurs_) {
    if (acteur->getNom() == nomActeur) {
      return true;
    }
  }
  return false;
}

/// @brief Verifie si une critique est présente dans la liste des critiques du
/// film
/// @param nomCritique Le nom de l'auteur de la critique à trouver
/// @return true si la critique est présente, false sinon
bool Film::isCritiquePresent(string nomCritique) const {
  for (const auto& critique : critiques_) {
    if (critique->getAuteur() == nomCritique) {
      return true;
    }
  }
  return false;
}

/// @brief calcule la note moyenne du film
/// @return La note moyenne du film
float Film::obtenirNoteMoyenne() const {
  float sum = 0.0;

  for (const auto& critique : critiques_) {
    sum += critique->getNote();
  }

  return sum / critiques_.size();
}

// Opérateurs
/// @brief Ajoute un acteur à la liste des acteurs du film
/// @param acteur L'acteur à ajouter
/// @return true si l'acteur a été ajouté, false sinon
bool Film::operator+=(shared_ptr<Acteur>& acteur) {
  if (isActeurPresent(acteur->getNom())) {
    return false;
  }

  acteurs_.push_back(acteur);

  return true;
}

/// @brief Ajoute une critique à la liste des critiques du film
/// @param critique La critique à ajouter
/// @return true si la critique a été ajoutée, false sinon
bool Film::operator+=(Critique* critique) {
  if (isCritiquePresent(critique->getAuteur())) {
    return false;
  }

  critiques_.push_back(make_unique<Critique>(*critique));
  return true;
}

/// @brief Verifie si deux films sont identiques
/// @param film Le film à comparer
/// @return true si les films sont identiques, false sinon
bool Film::operator==(const Film& film) const {
  bool shallowCheck = titre_ == film.titre_ &&
                      anneeDeSortie_ == film.anneeDeSortie_ &&
                      realisateur_ == film.realisateur_ &&
                      categorie_ == film.categorie_ && duree_ == film.duree_;

  if (shallowCheck == false) {
    return false;
  }

  for (const auto& critique : critiques_) {
    if (film.isCritiquePresent(critique->getAuteur()) == false) {
      return false;
    }
  }

  for (const auto& acteur : acteurs_) {
    if (film.isActeurPresent(acteur->getNom()) == false) {
      return false;
    }
  }

  return true;
}

/// @brief Verifie si deux films sont différents
/// @param film Le film à comparer
/// @return true si les films sont différents, false sinon
bool Film::operator!=(const Film& film) const {
  return !this->operator==(film);
}

/// @brief Retire un acteur de la liste des acteurs du film
/// @param acteur L'acteur à retirer
/// @return true si l'acteur a été retiré, false sinon
bool Film::operator-=(shared_ptr<Acteur>& acteur) {
  auto nom = acteur->getNom();
  for (size_t i = 0; i < acteurs_.size(); ++i) {
    auto acteur_it = acteurs_[i];
    if (acteur_it->getNom() == nom) {
      // Une fois qu'on a trouve l'acteur, on le remplace par le dernier acteur,
      // et on enleve le dernier element dans la liste.
      // S'il n'y a qu'un element, ce dernier sera supprime directement, ce
      // n'est donc pas grave de mettre un nullptr a cet endroit.
      acteurs_[i] = acteurs_.back();
      acteurs_.pop_back();
      return true;
    }
  }
  return false;
}

/// @brief Retire une critique de la liste des critiques du film
/// @param critique La critique à retirer
/// @return true si la critique a été retirée, false sinon
bool Film::operator-=(Critique* critique) {
  auto nom = critique->getAuteur();
  for (size_t i = 0; i < critiques_.size(); ++i) {
    auto& critique_it = critiques_[i];
    if (critique_it->getAuteur() == nom) {
      // Une fois qu'on a trouve la critique, on la remplace par la derniere
      // critique, et on enleve le dernier element dans la liste.
      // S'il n'y a qu'un element, ce dernier sera supprime directement, ce
      // n'est donc pas grave de mettre un nullptr a cet endroit.
      critiques_[i] = move(critiques_.back());
      critiques_.pop_back();
      return true;
    }
  }
  return false;
}

// Méthode d'affichage
/// @brief Affiche le film
/// @param stream Le stream dans lequel afficher
/// @return Le stream dans lequel on a affiché
ostream& operator<<(ostream& os, const Film& film) {
  std::string categorieString;
  switch (film.categorie_) {
    case Categorie::ACTION:
      categorieString = "Action";
      break;
    case Categorie::DRAME:
      categorieString = "Drame";
      break;
    case Categorie::COMEDIE:
      categorieString = "Comedie";
      break;
    case Categorie::HORREUR:
      categorieString = "Horreur";
      break;
  }
  os << film.titre_ << " (" << film.anneeDeSortie_ << ") de "
     << film.realisateur_ << endl
     << "Duree: " << film.duree_ << " minutes" << endl
     << "Categorie: " << categorieString << endl
     << "Acteurs:" << endl;

  for (const auto& acteur : film.acteurs_) {
    cout << *acteur;
  }

  os << "Critiques:" << endl;

  for (const auto& critique : film.critiques_) {
    cout << "\t" << *critique;
  }

  os << "Note moyenne: " << film.obtenirNoteMoyenne() << endl;
  return os;
}
