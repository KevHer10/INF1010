/**
 * Implementation de la classe Polyflix
 * \author Remi Marche et Rebay Mohamed
 * \date 22 septembre 2023
 * Cree le 22 septembre 2023
 */

#include "Polyflix.h"
#include <algorithm>

string SEPARATEUR =
    "=========================================================================="
    "============";

// Constructeur
Polyflix::Polyflix() {}

// Copy Constructor
/// @brief Constructeur par copie de la classe Polyflix
/// @param poyflix Le Polyflix à copier
Polyflix::Polyflix(const Polyflix& polyflix)
    : utilisateurs_(polyflix.utilisateurs_), films_() {
  for (const auto& film : polyflix.films_) {
    films_.push_back(make_unique<Film>(*film));
  }
}

// Méthodes pour la recherche
/// @brief Cherche un film par son titre
/// @param titre Le titre du film à chercher
/// @return Un pointeur vers le film trouvé, nullptr sinon
Film* Polyflix::chercherFilmParTitre(const string& titre) const {
  for (const auto& film : films_) {
    if (film->getTitre() == titre) {
      return film.get();
    }
  }
  return nullptr;
}

/// @brief Cherche un utilisateur par son nom d'utilisateur
/// @param nomUtilisateur Le nom d'utilisateur à chercher
/// @return Un pointeur vers l'utilisateur trouvé, nullptr sinon
Utilisateur* Polyflix::chercherUtilisateur(const string& nomUtilisateur) {
  for (auto& utilisateur : utilisateurs_) {
    if (utilisateur.getNomUtilisateur() == nomUtilisateur) {
      return &utilisateur;
    }
  }
  return nullptr;
}

// Méthodes liées aux utilisateurs
int Polyflix::getNombreUtilisateurs() const {
  return (int)utilisateurs_.size();
}

/// @brief Vérifie si un utilisateur existe
/// @param nomUtilisateur Le nom de l'utilisateur à vérifier
/// @return Vrai si l'utilisateur existe, faux sinon
bool Polyflix::utilisateurExiste(const string& nomUtilisateur) {
  for (const auto& utilisateur : utilisateurs_) {
    if (utilisateur.getNomUtilisateur() == nomUtilisateur) {
      return true;
    }
  }
  return false;
}

/// @brief Connecte un utilisateur
/// @param nomUtilisateur Le nom de l'utilisateur à connecter
/// @param motDePasse Le mot de passe de l'utilisateur à connecter
/// @return Vrai si l'utilisateur a été connecté, faux sinon
bool Polyflix::connecterUtilisateur(string nomUtilisateur, string motDePasse) {
  auto utilisateur = chercherUtilisateur(nomUtilisateur);
  if (utilisateur == nullptr) {
    return false;
  }
  return utilisateur->verifierConnexion(motDePasse);
}

/// @brief Modifie le mot de passe d'un utilisateur
/// @param nomUtilisateur Le nom de l'utilisateur à modifier
/// @param motDePasse Le nouveau mot de passe de l'utilisateur
bool Polyflix::modifierMotDePasse(string nomUtilisateur, string motDePasse) {
  auto utilisateur = chercherUtilisateur(nomUtilisateur);

  if (utilisateur == nullptr) {
    return false;
  }

  utilisateur->setMotDePasse(motDePasse);
  return true;
}

/// @brief Visionne un film
/// @param nomUtilisateur l'utilisateur qui visionne le film
/// @param titreFilm le titre du film à visionner
/// @return vrai si le film a été visionné
bool Polyflix::visionnerFilm(string nomUtilisateur, string titreFilm) {
  auto utilisateur = chercherUtilisateur(nomUtilisateur);
  if (utilisateur == nullptr) {
    return false;
  }

  auto film = chercherFilmParTitre(titreFilm);

  if (film == nullptr) {
    return false;
  }

  utilisateur->ajouterFilm(make_shared<Film>(*film));
  return true;
}

// Méthodes pour obtenir des statistiques
int Polyflix::getNombreTotalFilms() const {
  return (int)films_.size();
}

/// @brief Retourne le nombre de films d'une catégorie
/// @param categorie La catégorie des films à compter
/// @return Le nombre de films de la catégorie
int Polyflix::getNombreFilmsParCategorie(Categorie categorie) const {
  int nombreFilms = 0;
  for (const auto& film : films_) {
    if (film->getCategorie() == categorie) {
      nombreFilms++;
    }
  }
  return nombreFilms;
}

/// @brief Retourne le nombre total de films visionnés
/// @return Le nombre total de films visionnés
int Polyflix::getNombreTotalFilmsVisionnes() const {
  int nombreFilmsVisionnes = 0;
  for (const auto& utilisateur : utilisateurs_) {
    nombreFilmsVisionnes += utilisateur.getFilmsVus().size();
  }
  return nombreFilmsVisionnes;
}

/// @brief Retourne le nombre d'utilisateurs ayant visionné un film
/// @param titreFilm Le titre du film à chercher
/// @return Le nombre d'utilisateurs ayant visionné le film
int Polyflix::getNombreUtilisateursAyantVisionne(
    const string& titreFilm) const {
  int nombreUtilisateurs = 0;
  for (const auto& utilisateur : utilisateurs_) {
    const auto& filmsVus = utilisateur.getFilmsVus();
    for (const auto& film : filmsVus) {
      if (film->getTitre() == titreFilm) {
        nombreUtilisateurs++;
        break;
      }
    }
  }
  return nombreUtilisateurs;
}

/// @brief Retourne le film avec la plus haute note
/// @return Le film avec la plus haute note
unique_ptr<Film> Polyflix::obtenirFilmAvecLaPlusHauteNote() const {
  float noteMax = 0;
  Film* filmMax = nullptr;

  for (const auto& film : films_) {
    float note = film->obtenirNoteMoyenne();
    if (note > noteMax) {
      noteMax = note;
      filmMax = film.get();
    }
  }
  return make_unique<Film>(*filmMax);
}

/// @brief Retourne le film avec la plus basse note
/// @return Le film avec la plus basse note
unique_ptr<Film> Polyflix::obtenirFilmAvecLaPlusBasseNote() const {
  float noteMin = 6;
  Film* filmMin = nullptr;

  for (const auto& film : films_) {
    float note = film->obtenirNoteMoyenne();
    if (note < noteMin) {
      noteMin = note;
      filmMin = film.get();
    }
  }
  return make_unique<Film>(*filmMin);
}

/// @brief Retourne le film le plus récent
/// @return Le film le plus récent
unique_ptr<Film> Polyflix::obtenirFilmPlusRecent() const {
  int anneeMax = 0;
  Film* filmMax = nullptr;

  for (const auto& film : films_) {
    int annee = film->getAnneeDeSortie();
    if (annee > anneeMax) {
      anneeMax = annee;
      filmMax = film.get();
    }
  }
  return make_unique<Film>(*filmMax);
}

/// @brief Retourne les films d'une catégorie
/// @param categorie La catégorie des films à retourner
vector<unique_ptr<Film>> Polyflix::listerFilmsParCategorie(
    Categorie categorie) const {
  vector<unique_ptr<Film>> filmsParCategorie;
  for (const auto& film : films_) {
    if (film->getCategorie() == categorie) {
      filmsParCategorie.push_back(make_unique<Film>(*film));
    }
  }
  return filmsParCategorie;
}

/// @brief Retourne les films visionnés par un utilisateur
/// @param nomUtilisateur Le nom de l'utilisateur
/// @return Les films visionnés par l'utilisateur
vector<shared_ptr<Film>> Polyflix::listerFilmsVisionnesParUtilisateur(
    const string& nomUtilisateur) {
  auto utilisateur = chercherUtilisateur(nomUtilisateur);
  if (utilisateur == nullptr) {
    return vector<shared_ptr<Film>>();
  }
  return utilisateur->getFilmsVus();
}

// Opérateurs
/// @brief Ajoute un utilisateur
/// @param utilisateur L'utilisateur à ajouter
/// @return Vrai si l'utilisateur a été ajouté, faux sinon
bool Polyflix::operator+=(Utilisateur utilisateur) {
  if (utilisateurExiste(utilisateur.getNomUtilisateur())) {
    return false;
  }
  utilisateurs_.push_back(utilisateur);
  return true;
}

/// @brief Ajoute un film
/// @param film Le film à ajouter
/// @return Vrai si le film a été ajouté, faux sinon
bool Polyflix::operator+=(Film* film) {
  if (chercherFilmParTitre(film->getTitre()) != nullptr) {
    return false;
  }
  films_.push_back(make_unique<Film>(*film));
  return true;
}

/// @brief Retire un film
/// @param titre Le titre du film à retirer
/// @return Vrai si le film a été retiré, faux sinon
bool Polyflix::operator-=(string titre) {
  for (size_t i = 0; i < films_.size(); i++) {
    if (films_[i]->getTitre() == titre) {
      films_[i] = move(films_[films_.size() - 1]);
      films_.pop_back();
      return true;
    }
  }
  return true;
}

/// @brief Retourne un film
/// @param titre Le titre du film à retourner
/// @return Un pointeur vers le film, nullptr sinon
Film* Polyflix::operator[](string titre) {
  return chercherFilmParTitre(titre);
}

// Méthodes pour l'affichage
/// @brief Affiche les films
/// @param os Le stream dans lequel afficher
/// @param polyflix Le Polyflix à afficher
/// @return Le stream dans lequel afficher
ostream& operator<<(ostream& os, const Polyflix& polyflix) {
  os << SEPARATEUR << endl
     << "Polyflix vous presente les films suivants:" << endl
     << SEPARATEUR << endl;

  for (const auto& film : polyflix.films_) {
    os << *film << SEPARATEUR << endl;
  }

  return os;
}
