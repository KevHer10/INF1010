/**
 * Implementation de la classe Critique
 * \author Remi Marche et Rebay Mohamed
 * \date 22 septembre 2023
 * Cree le 22 septembre 2023
 */

#include "Critique.h"

// Constructeurs
Critique::Critique() : auteur_(""), commentaire_(""), note_(0) {}

Critique::Critique(std::string auteur, std::string contenu, int note)
    : auteur_(auteur), commentaire_(contenu), note_(note) {}

/// @brief Constructeur par copie d'une critique
/// @param critique La critique à copier
Critique::Critique(const Critique& critique)
    : auteur_(critique.auteur_),
      commentaire_(critique.commentaire_),
      note_(critique.note_) {}

/// @brief l'opérateur d'affectation d'une critique
/// @param critique La critique à copier
/// @return La critique copiée, pour permettre les assignations en cascade
Critique& Critique::operator=(const Critique& critique) {
  if (this == &critique) {
    return *this;
  }

  auteur_ = critique.auteur_;
  commentaire_ = critique.commentaire_;
  note_ = critique.note_;

  return *this;
}

// Getters
string Critique::getAuteur() const {
  return auteur_;
}

string Critique::getCommentaire() const {
  return commentaire_;
}

int Critique::getNote() const {
  return note_;
}

// Setters
void Critique::setAuteur(string auteur) {
  this->auteur_ = auteur;
}

void Critique::setCommentaire(string contenu) {
  this->commentaire_ = contenu;
}

void Critique::setNote(int note) {
  this->note_ = note;
}

// Opérateurs
/// @brief L'opérateur de comparaison d'égalité entre deux critiques
/// @param critique La critique à comparer
/// @return true si les deux critiques sont égales, false sinon
bool Critique::operator==(const Critique& critique) const {
  return critique.auteur_ == auteur_ && critique.commentaire_ == commentaire_ &&
         critique.note_ == note_;
}

/// @brief L'opérateur de comparaison de différence entre deux critiques
/// @param critique La critique à comparer
/// @return true si les deux critiques sont différentes, false sinon
bool Critique::operator!=(const Critique& critique) const {
  return !this->operator==(critique);
}

// Méthodes pour l'affichage
/// @brief L'opérateur d'affichage d'une critique
/// @param os Le stream dans lequel afficher
/// @param critique La critique à afficher
/// @return Le stream dans lequel on a affiché la critique
ostream& operator<<(ostream& os, const Critique& critique) {
  os << critique.auteur_ << ": " << critique.commentaire_
     << " - Note: " << critique.note_ << endl;

  return os;
}
